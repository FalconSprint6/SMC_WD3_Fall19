# smc-gr67-web3
## Jennifer Morehead
A repo to hold all my in-class code from Web Design 3 at SMC
